import os

if __name__ == "__main__":
    print("作为主程序运行")
else:
    print('主程序运行失败')

