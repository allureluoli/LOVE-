for i in range(1,101):
    if i%3==2 and i %5==3 and i%7==2:
        print(i)
    i=i+1



