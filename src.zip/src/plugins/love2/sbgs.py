gs=""
while gs !="爸爸":
    gs=input("gs叫爸爸！\n")
    print("我是gs的爹哦")

print("儿子真乖")
